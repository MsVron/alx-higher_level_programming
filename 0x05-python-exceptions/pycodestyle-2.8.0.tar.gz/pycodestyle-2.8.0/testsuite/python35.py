#: E225
def bar(a, b)->int:
    pass
#: Okay
def baz(a, b) -> int:
    pass
